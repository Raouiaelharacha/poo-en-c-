#include<iostream>
using namespace std;
class mere{
	public:
		void display(){
			cout<<"je suis une mere";
			
			
		}	
};
class fille:public mere{
	public:
		void display(){
			cout<<"je suis une fille";
			
		}
		
};
main(){ 
	fille f;
	f.display();//on va faire  appel fct display de class fille car le type d'objet f est de class fille
// on peut acceder au fct d'une classe a travers les objets on aussi acceder au variable d'une class atravers les objets ex: c1.rel
//avec rel variable de class
	return 0;
	
	
}
