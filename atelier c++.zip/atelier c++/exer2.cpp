#include<iostream>
using namespace std;
class shape{
	protected:
	float l,h;
	public:
		shape(float x,float y){
			l=x;
			h=y;	
		}	
};
class Rectangle:public shape{
	public:
		Rectangle(float x,float y):shape(x,y){}
		float area(){
			return (h*l);
		}
};
 class Triangle:public shape{
 	public:
	    Triangle(float x,float y):shape(x,y){}
 		float area(){
 			return (h*l/2);
 			
		 }	
	
 };
 main(){
 	Rectangle R(1,3);//1=R.l et 3=R.l
 	Triangle T(1,3);
 	cout<<endl<<"la surface du rectangle est:"<<R.area();
 	cout<<endl<<"la surface du triangle est:"<<T.area();
 		
 }



