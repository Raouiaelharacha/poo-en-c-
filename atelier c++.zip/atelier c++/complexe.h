#include <iostream>
#include<math.h>
using namespace std;
class complexe{
	
	int *rel;
	int *img;
	static int z;
	public:
		 complexe();
		complexe(int x, int y); // constructor convoqu� lors creation d'objet;
		static void affi();//pour afficher Z qui est nbre des objets crees
		void afficher();
		float module();
	    friend complexe somme(const complexe&, const complexe&);
	    ~complexe();//destrecteur pour supp espace memeoire donnes par constr
	    void test();
		friend ostream& operator <<(ostream& , const complexe&);
		friend istream& operator >>(istream& , complexe&);
	    complexe& operator=(const complexe&);//pour la surcharge d'affectation = on la define comme methode
		complexe& operator+(const complexe&);
		complexe& operator-(const complexe&);//meme processus pour division
		complexe& operator/(const complexe&);
		complexe& operator++();
		int operator==(const complexe);//la surcharge de ==
};
complexe somme(const complexe&, const complexe&);//type de retour de cette fct est un complexe il va returner un complexe(complexe somme)
ostream& operator <<(ostream& , const complexe&);
istream& operator >>(istream& , complexe&);

