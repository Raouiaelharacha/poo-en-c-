#include<iostream>
#include<string>
using namespace std;
 class my_class{
 	string name,p;
 	
 	public:
 	my_class();
 	~my_class();
 	
 	
 };
my_class::my_class(){
 
 	cin>>name;
 	cout<<endl<<"bonjour  "<<name;
 	
 }
 my_class::~my_class(){
 	
 	cin>>p;
 	cout<<"au revoir  "<<p;
 	
 }

	
 main(){
 	my_class A;
 	
 }
