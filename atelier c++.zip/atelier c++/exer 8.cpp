#include<iostream>
using namespace std;
class Media {
public:
virtual void imprime();
virtual char *id();
protected:
String titre;
};
class Livre: public Media {
public:
Livre() { 
}
protected:
String auteur, editeur, isbn;
};

class audio:public Media{
	private:
		string type;
		int puissance;
		
};
class press:public Media{
	protected:
		string nom,association;
};
class CD:public audio{
	private:
		string nom;
		
	
};
class casquettes:public audio{
	private:
		int voltage;
		
	
};
class Disque:public audio{
	private:
		float nbre GO;
			
};
class magazine:public press{
	private:
		string titre magazine;
		
		
	
};
class journal:public press{
	private:
		int reference;
		
};
class Revue:public press
{
	private:
		int nbre de page;
}

